*PADS-LIBRARY-PART-TYPES-V9*

IP2312 SOIC127P600X165-9N I ANA 9 1 0 0 0
TIMESTAMP 2026.08.01.00.28.49
"Manufacturer_Name" INJOINIC
"Manufacturer_Part_Number" IP2312
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" ESOP-8L DC-DC Converters RoHS
"Datasheet Link" http://www.injoinic.com/wwwroot/uploads/files/20230913/623558e526750db62e25e32800f94a6b.pdf
"Geometry.Height" 1.65mm
GATE 1 9 0
IP2312
1 0 U D1
2 0 U TEST
3 0 U D2
4 0 U NTC
9 0 U GND
8 0 U VIN
7 0 U SW
6 0 U ICHG
5 0 U BAT

*END*
*REMARK* SamacSys ECAD Model
12854697/2035748/2.50/9/3/Integrated Circuit
